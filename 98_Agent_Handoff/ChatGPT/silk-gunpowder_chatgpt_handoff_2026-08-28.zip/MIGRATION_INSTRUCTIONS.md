# Instrucciones De Migracion

Este paquete fue preparado por ChatGPT para integrarse manualmente al repositorio local de `silk---gunpowder`.

## Destino

Copiar el contenido de esta carpeta sobre la raiz del repositorio local.

Los archivos estan organizados con sus rutas reales.

## Archivos Incluidos

- `98_Agent_Handoff/AGENT_ROLES.md` — archivo nuevo.
- `98_Agent_Handoff/README.md` — reemplazo propuesto.
- `98_Agent_Handoff/START_HERE.md` — reemplazo propuesto.
- `98_Agent_Handoff/sessions/2026-08-28_chatgpt_para_codex_claude_roles_agentes.md` — nota de relevo.

## Antes De Commit

Pedir a Codex o Claude Code:

1. revisar `git diff`;
2. comprobar si `README.md` o `START_HERE.md` cambiaron en remoto/local desde que se preparo este paquete;
3. fusionar manualmente si existe contenido mas reciente;
4. confirmar que no se altera canon narrativo;
5. hacer commit sobre `develop`.

Commit sugerido:

`docs: formaliza roles y handoff entre agentes`
